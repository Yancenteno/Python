# class Player:
#     Game_Name= 'Ninja vs Pirate'
    
#     Player_List= []
    
#     def __init__(self, name):
#         self.name = name
        